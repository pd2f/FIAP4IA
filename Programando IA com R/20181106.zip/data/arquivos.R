


baixarArquivo <- function(url) {
  if (!file.exists('data')) {
    dir.create('data')
  }
  file.local = file.path('./data', basename(url))
  download.file(url = url,
                destfile = file.local,
                mode = 'wb')
}

baixarArquivo('https://github.com/pd2f/FIAP4IA/dump_variaveis_cidr.RData')
baixarArquivo('https://raw.githubusercontent.com/elthonf/fiap-mba-r/master/data/Copas.csv')
baixarArquivo('https://raw.githubusercontent.com/elthonf/fiap-mba-r/master/data/Copas-Partidas.csv')
baixarArquivo('https://raw.githubusercontent.com/elthonf/fiap-mba-r/master/data/Copas-Jogadores.csv')


Copas_Partidas <- read_csv("./data/Copas-Partidas.csv")
Copas_Jogadores <- read_csv("./data/Copas-Jogadores.csv")
Copas <- read_csv("./data/Copas.csv")

class(Copas_Partidas)
class(Copas_Jogadores)
class(Copas)

head(Copas_Jogadores)

baixarArquivo(
  'https://raw.githubusercontent.com/elthonf/fiap-mba-r/master/data/cameras.baltimore.xlsx'
)

install.packages("xlsx", dependencies = TRUE)
library(xlsx)
library(readxl)
cameras <- read_excel("data/cameras.baltimore.xlsx")

install.packages("dplyr")
library(dplyr)

mais_ao_norte <-   select(filter(cameras, Lat == max(Lat)), address)
mais_ao_sul <-   select(filter(cameras, Lat == min(Lat)), address)
mais_ao_lest <-   select(filter(cameras, Long == max(Long)), address)
mais_ao_oest <-   select(filter(cameras, Long == min(Long)), address)


sw <- mutate(starwars, imc = (mass/((height/100)^2)))
head(BrFlights2)

newBRFlieghts <- mutate(BrFlights2,Partida.Atraso = Partida.Prevista - Partida.Real,
       Chegada.Atraso = Chegada.Prevista - Chegada.Real ,
       DistanciaEuc = sqrt(((LongOrig - LongDest)^2) + ((LatOrig - LatDest)^2)), 
       TempoViagem.Real = Chegada.Real - Partida.Real)

select(newBRFlieghts,Chegada.Atraso, Partida.Atraso, DistanciaEuc, TempoViagem.Real)


install.packages("magrittr")
library(magrittr)
?magrittr

install.packages("pipe")


sw%>%View(.,"teste")


x <- BrFlights2 %>% mutate(.,Partida.Atraso = Partida.Prevista - Partida.Real,
                           Chegada.Atraso = Chegada.Prevista - Chegada.Real ,
                           DistanciaEuc = sqrt(((LongOrig - LongDest)^2) + ((LatOrig - LatDest)^2)), 
                           TempoViagem.Real = Chegada.Real - Partida.Real)


install.packages("magrittr")
library(magrittr)

iris$Sepal.Length %<>% sqrt

iris$Sepal.Length

x <- rnorm(100)

x %<>% abs %>% sort

is_weekend <- function(day)
{
  # day could be e.g. character a valid representation
  day %<>% as.Date
  
  result <- day %>% format("%u") %>% as.numeric %>% is_greater_than(5)
  
  if (result)
    message(day %>% paste("is a weekend!"))
  else
    message(day %>% paste("is not a weekend!"))
  

  
  
  
  
  invisible(result)
}


rnorm(200) %>% 
matrix(ncol = 2) %T>%
plot %>%colSums

starwars %>%select(name)
head(newBRFlieghts)

x <- newBRFlieghts %>% select(Voos:Partida.Prevista,
                              Partida.Real,
                              Partida.Atraso,
                              Chegada.Prevista,
                              Chegada.Real,
                              Chegada.Atraso,
                              TempoViagem.Real,
                              Situacao.Voo:DistanciaEuc)


starwars %>%
  arrange(desc(mass))

  x %>% arrange(desc(Chegada.Atraso)) %>% head(1) %>% select(Aeroporto.Origem)
  